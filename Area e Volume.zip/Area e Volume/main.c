#include <stdio.h>
#define PI 3

int areaCirculo (int raioC);

int areaQuadrado (int larguraQ);

int areaRetangulo (int larguraR, int comprimento);

int volumeCubo (int larguraC);

int volumeEsfera (int raioE, int altura);

void tabelaCalculos (void);

int main() {
    int rC, circulo;
    int largQ, quadrado;
    int largR, comp, retangulo;
    int largC, cubo;
    int rE, alt, esfera;
    int resposta, continuar;

    do {
        tabelaCalculos();
        printf("\n Digite um dos valores acima, para selecionar o calculo: ");
        scanf("%i", &resposta);
        printf("\n---------------------------------\n");

        switch (resposta) {
            case 1 :
                printf(" Digite o raio do circulo: ");
                scanf("%i", &rC);
                circulo = areaCirculo(rC);
                printf(" A area do circulo e: %i \n", circulo);
            break;

            case 2 :
                printf(" Digite a largura do quadrado: ");
                scanf("%i", &largQ);
                quadrado = areaQuadrado(largQ);
                printf(" A area do quadrado e: %i \n", quadrado);
            break;

            case 3 :
                printf(" Digite a largura e o comprimentod do retangulo: ");
                scanf("%i %i", &largR, &comp);
                retangulo = areaRetangulo(largR, comp);
                printf("\n A area do retangulo e: %i \n", retangulo);
            break;

            case 4 :
                printf(" Digite a largura do cubo: ");
                scanf("%i", &largC);
                cubo = volumeCubo(largC);
                printf(" O volume do cubo e: %i \n", cubo);
            break;

            case 5 :
                printf(" Digite o raio e altura da esfera: ");
                scanf("%i %i", &rE, &alt);
                esfera = volumeEsfera(rE, alt);
                printf("\n O volume da esfera e: %i \n", esfera);
            break;

            default :
                printf(" Digite somente os valores mencionados.");
        }

        printf("---------------------------------\n");
        printf("\n Deseja realizar mais algum calculo?\n");
        printf(" Digite 1 para continuar ou 2 para sair: ");
        scanf("%i", &continuar);
        printf("\n");
    } while (continuar == 1);

    return 0;
}

int areaCirculo (int raioC) {
    int resultadoAC;
    resultadoAC = PI * raioC * raioC;

    return resultadoAC;
}

int areaQuadrado (int larguraQ) {
    int resultadoAQ;
    resultadoAQ = larguraQ * larguraQ;

    return resultadoAQ;
}

int areaRetangulo (int larguraR, int comprimento) {
    int resultadoAR;
    resultadoAR = larguraR * comprimento;

    return resultadoAR;
}

int volumeCubo (int larguraC) {
    int resultadoVC;
    resultadoVC = larguraC * larguraC * larguraC;

    return resultadoVC;
}

int volumeEsfera (int raioE, int altura) {
    int resultadoVE;
    resultadoVE = (altura / 3) * PI * raioE * raioE * raioE;

    return resultadoVE;
}

void tabelaCalculos (void) {
    printf(" -----------------------\n");
    printf(" [1] Area do Circulo.  |\n");
    printf(" [2] Area do Quadrado. |\n");
    printf(" [3] Area do Retangulo.|\n");
    printf(" [4] Volume do Cubo.   |\n");
    printf(" [5] Volume da Esfera. |\n");
    printf(" -----------------------\n");

    return;
}